using UnityEngine;

// 2주차 베이스용 간단 이동 스크립트.
// 키보드 방향키/WASD로 움직인다.
// 4주차에서 New Input System으로 리팩토링합니다.
public class PlayerMove : MonoBehaviour
{
    public float speed = 5f;

    void Update()
    {
        float h = Input.GetAxisRaw("Horizontal"); // A/D, ←/→
        float v = Input.GetAxisRaw("Vertical");   // W/S, ↑/↓
        Vector3 dir = new Vector3(h, 0f, v).normalized;
        transform.position += dir * speed * Time.deltaTime;
    }
}
